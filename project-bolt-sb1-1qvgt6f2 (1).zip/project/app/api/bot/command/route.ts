import { NextResponse } from 'next/server';
import { createSupabaseServerClient } from '@/lib/supabase-server';

export async function POST(request: Request) {
  const supabase = createSupabaseServerClient();

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
  }

  const body = await request.json();
  const { command, server_id, target_id, reason } = body;

  if (!command) {
    return NextResponse.json({ error: 'الأمر مطلوب' }, { status: 400 });
  }

  const validCommands = ['kick', 'ban', 'mute', 'unmute', 'unban', 'clear', 'say', 'ping'];
  if (!validCommands.includes(command)) {
    return NextResponse.json({ error: 'أمر غير صالح' }, { status: 400 });
  }

  const userMetadata = user.user_metadata as { name?: string; full_name?: string } | undefined;
  const username = userMetadata?.name || userMetadata?.full_name || 'Admin';

  // Log the command
  const { error: logError } = await supabase.from('logs').insert({
    server_id: server_id || null,
    user_id: user.id,
    username,
    action: command,
    target_id: target_id || null,
    reason: reason || null,
    details: { source: 'dashboard', timestamp: new Date().toISOString() },
  });

  if (logError) {
    return NextResponse.json({ error: logError.message }, { status: 500 });
  }

  // Handle member status updates for moderation commands
  if (command === 'ban' && target_id) {
    await supabase.from('members').update({ is_banned: true }).eq('user_id', target_id);
  } else if (command === 'unban' && target_id) {
    await supabase.from('members').update({ is_banned: false }).eq('user_id', target_id);
  } else if (command === 'mute' && target_id) {
    await supabase.from('members').update({ is_muted: true }).eq('user_id', target_id);
  } else if (command === 'unmute' && target_id) {
    await supabase.from('members').update({ is_muted: false }).eq('user_id', target_id);
  }

  return NextResponse.json({
    success: true,
    message: `تم تنفيذ الأمر: ${command}`,
  });
}

import { NextResponse } from 'next/server';
import { createSupabaseServerClient } from '@/lib/supabase-server';

export async function GET() {
  const supabase = createSupabaseServerClient();

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
  }

  const { data, error } = await supabase
    .from('settings')
    .select('*');

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data);
}

export async function POST(request: Request) {
  const supabase = createSupabaseServerClient();

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
  }

  const body = await request.json();
  const {
    server_id,
    prefix,
    welcome_enabled,
    welcome_channel_id,
    welcome_message,
    logs_enabled,
    logs_channel_id,
    security_enabled,
    auto_mod_enabled,
  } = body;

  if (!server_id) {
    return NextResponse.json({ error: 'معرف السيرفر مطلوب' }, { status: 400 });
  }

  const { data: existing } = await supabase
    .from('settings')
    .select('id')
    .eq('server_id', server_id)
    .maybeSingle();

  if (existing) {
    const { data, error } = await supabase
      .from('settings')
      .update({
        prefix,
        welcome_enabled,
        welcome_channel_id,
        welcome_message,
        logs_enabled,
        logs_channel_id,
        security_enabled,
        auto_mod_enabled,
        updated_at: new Date().toISOString(),
      })
      .eq('server_id', server_id)
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json(data);
  } else {
    const { data, error } = await supabase
      .from('settings')
      .insert({
        server_id,
        prefix,
        welcome_enabled,
        welcome_channel_id,
        welcome_message,
        logs_enabled,
        logs_channel_id,
        security_enabled,
        auto_mod_enabled,
      })
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json(data);
  }
}

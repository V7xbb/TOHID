import { NextResponse } from 'next/server';
import { createSupabaseServerClient } from '@/lib/supabase-server';

export async function GET() {
  const supabase = createSupabaseServerClient();

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
  }

  const [serversRes, membersRes, logsRes, bannedRes, mutedRes] = await Promise.all([
    supabase.from('servers').select('*'),
    supabase.from('members').select('*'),
    supabase.from('logs').select('action, created_at'),
    supabase.from('members').select('id').eq('is_banned', true),
    supabase.from('members').select('id').eq('is_muted', true),
  ]);

  const servers = serversRes.data ?? [];
  const members = membersRes.data ?? [];
  const logs = logsRes.data ?? [];

  // Commands by day (last 7 days)
  const now = new Date();
  const daysMap: Record<string, number> = {};
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().split('T')[0];
    daysMap[key] = 0;
  }
  logs.forEach((log) => {
    const key = log.created_at?.split('T')[0];
    if (key && key in daysMap) {
      daysMap[key]++;
    }
  });
  const commandsByDay = Object.entries(daysMap).map(([date, count]) => ({
    date: new Date(date).toLocaleDateString('ar-EG', { weekday: 'short', day: 'numeric' }),
    count,
  }));

  // Commands by type
  const typeMap: Record<string, number> = {};
  logs.forEach((log) => {
    typeMap[log.action] = (typeMap[log.action] || 0) + 1;
  });
  const commandsByType = Object.entries(typeMap)
    .map(([action, count]) => ({ action, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  // Members by server
  const membersByServer = servers.map((s) => ({
    name: s.name,
    count: members.filter((m) => m.server_id === s.server_id).length,
  }));

  return NextResponse.json({
    totalServers: servers.length,
    totalMembers: members.length,
    totalCommands: logs.length,
    botStatus: 'online' as const,
    activeServers: servers.filter((s) => s.member_count > 0).length,
    bannedMembers: bannedRes.data?.length ?? 0,
    mutedMembers: mutedRes.data?.length ?? 0,
    commandsByDay,
    commandsByType,
    membersByServer,
  });
}

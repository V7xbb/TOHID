'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Code2, Database, GitBranch, Server, Terminal, Zap, CheckCircle, XCircle } from 'lucide-react';

const apiRoutes = [
  { method: 'GET', path: '/api/servers', description: 'قائمة السيرفرات' },
  { method: 'GET', path: '/api/members', description: 'قائمة الأعضاء' },
  { method: 'GET', path: '/api/stats', description: 'الإحصائيات العامة' },
  { method: 'GET', path: '/api/settings', description: 'عرض الإعدادات' },
  { method: 'POST', path: '/api/settings', description: 'تعديل الإعدادات' },
  { method: 'GET', path: '/api/logs', description: 'عرض السجلات' },
  { method: 'POST', path: '/api/bot/command', description: 'تنفيذ أمر على البوت' },
  { method: 'GET', path: '/api/auth/callback', description: 'رد نداء Discord OAuth' },
];

const dbTables = [
  { name: 'bot_admins', columns: 5, rls: true },
  { name: 'servers', columns: 10, rls: true },
  { name: 'members', columns: 12, rls: true },
  { name: 'settings', columns: 11, rls: true },
  { name: 'logs', columns: 10, rls: true },
];

const botCommands = [
  { cmd: 'ping', desc: 'فحص استجابة البوت' },
  { cmd: 'echo', desc: 'تكرار رسالة' },
  { cmd: 'kick', desc: 'طرد عضو' },
  { cmd: 'ban', desc: 'حظر عضو' },
  { cmd: 'clear', desc: 'تنظيف الرسائل' },
  { cmd: 'say', desc: 'إرسال رسالة كالبوت' },
  { cmd: 'serverinfo', desc: 'معلومات السيرفر' },
  { cmd: 'userinfo', desc: 'معلومات عضو' },
];

export default function DeveloperPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">صفحة المطور</h1>
        <p className="text-muted-foreground mt-1">معلومات تقنية عن النظام</p>
      </div>

      {/* System Status */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="card-glow">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">حالة البوت</p>
                <p className="text-lg font-bold mt-1 text-success">متصل</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success/10">
                <CheckCircle className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">قاعدة البيانات</p>
                <p className="text-lg font-bold mt-1 text-success">Supabase</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success/10">
                <Database className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">الإطار</p>
                <p className="text-lg font-bold mt-1">Next.js 13</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <Code2 className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Realtime</p>
                <p className="text-lg font-bold mt-1 text-success">نشط</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-info/10">
                <Zap className="h-6 w-6 text-info" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* API Routes */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
              <Terminal className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle>API Routes</CardTitle>
              <CardDescription>مسارات الـ API المتاحة</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {apiRoutes.map((route) => (
              <div
                key={route.path + route.method}
                className="flex items-center gap-3 rounded-lg border p-3 hover:bg-accent/50 transition-colors"
              >
                <Badge
                  variant={route.method === 'GET' ? 'secondary' : 'default'}
                  className="font-mono text-xs w-16 justify-center"
                >
                  {route.method}
                </Badge>
                <code className="text-sm font-mono flex-1">{route.path}</code>
                <span className="text-sm text-muted-foreground">{route.description}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Database Tables */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-success/10">
              <Database className="h-5 w-5 text-success" />
            </div>
            <div>
              <CardTitle>جداول قاعدة البيانات</CardTitle>
              <CardDescription>هيكل البيانات في Supabase PostgreSQL</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 sm:grid-cols-2">
            {dbTables.map((table) => (
              <div key={table.name} className="rounded-lg border p-3">
                <div className="flex items-center justify-between">
                  <code className="text-sm font-mono font-medium">{table.name}</code>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">{table.columns} أعمدة</Badge>
                    {table.rls ? (
                      <Badge className="bg-success/10 text-success text-xs gap-1">
                        <CheckCircle className="h-3 w-3" /> RLS
                      </Badge>
                    ) : (
                      <Badge variant="destructive" className="text-xs gap-1">
                        <XCircle className="h-3 w-3" /> No RLS
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Bot Commands */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-warning/10">
              <GitBranch className="h-5 w-5 text-warning" />
            </div>
            <div>
              <CardTitle>أوامر البوت</CardTitle>
              <CardDescription>أوامر Discord.js v14 المتاحة</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 sm:grid-cols-2">
            {botCommands.map((cmd) => (
              <div key={cmd.cmd} className="flex items-center gap-3 rounded-lg border p-3">
                <code className="text-sm font-mono font-medium text-primary">!{cmd.cmd}</code>
                <span className="text-sm text-muted-foreground flex-1">{cmd.desc}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tech Stack */}
      <Card>
        <CardHeader>
          <CardTitle>التقنيات المستخدمة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {['Next.js', 'React', 'TypeScript', 'TailwindCSS', 'ShadCN/ui', 'Supabase', 'Discord.js v14', 'Recharts', 'Lucide Icons'].map((tech) => (
              <Badge key={tech} variant="secondary" className="text-sm py-1.5">
                {tech}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

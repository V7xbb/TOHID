'use client';

import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollText, Terminal, UserPlus, ShieldBan, VolumeX, MessageSquare, Search, Trash2 } from 'lucide-react';
import type { BotLog } from '@/lib/types';
import { supabase } from '@/lib/supabase-client';

const actionIcons: Record<string, typeof Terminal> = {
  kick: ShieldBan,
  ban: ShieldBan,
  mute: VolumeX,
  unmute: VolumeX,
  unban: ShieldBan,
  clear: Trash2,
  say: MessageSquare,
  ping: Terminal,
  echo: MessageSquare,
  serverinfo: Terminal,
  userinfo: UserPlus,
  member_join: UserPlus,
};

const actionColors: Record<string, string> = {
  kick: 'bg-destructive/10 text-destructive',
  ban: 'bg-destructive/10 text-destructive',
  mute: 'bg-warning/10 text-warning',
  unmute: 'bg-success/10 text-success',
  unban: 'bg-success/10 text-success',
  clear: 'bg-info/10 text-info',
  say: 'bg-primary/10 text-primary',
  ping: 'bg-success/10 text-success',
  echo: 'bg-primary/10 text-primary',
  serverinfo: 'bg-info/10 text-info',
  userinfo: 'bg-info/10 text-info',
  member_join: 'bg-success/10 text-success',
};

export default function LogsPage() {
  const [logs, setLogs] = useState<BotLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [actionFilter, setActionFilter] = useState<string>('all');

  const fetchLogs = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (actionFilter !== 'all') params.set('action', actionFilter);
    params.set('page', String(page));
    params.set('pageSize', '15');

    fetch(`/api/logs?${params}`)
      .then((r) => r.json())
      .then((data) => {
        setLogs(data.data || []);
        setTotalPages(data.totalPages || 1);
        setTotal(data.total || 0);
        setLoading(false);
      });
  }, [actionFilter, page]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  // Realtime subscription
  useEffect(() => {
    const channel = supabase
      .channel('logs-changes')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'logs' }, () => {
        fetchLogs();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchLogs]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">السجلات</h1>
          <p className="text-muted-foreground mt-1">سجل أوامر وأحداث البوت ({total} سجل)</p>
        </div>
        <Select value={actionFilter} onValueChange={(v) => { setActionFilter(v); setPage(1); }}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="كل الأوامر" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الأوامر</SelectItem>
            <SelectItem value="kick">طرد</SelectItem>
            <SelectItem value="ban">حظر</SelectItem>
            <SelectItem value="mute">كتم</SelectItem>
            <SelectItem value="unmute">إلغاء كتم</SelectItem>
            <SelectItem value="clear">تنظيف</SelectItem>
            <SelectItem value="say">رسالة</SelectItem>
            <SelectItem value="ping">Ping</SelectItem>
            <SelectItem value="echo">Echo</SelectItem>
            <SelectItem value="serverinfo">معلومات السيرفر</SelectItem>
            <SelectItem value="userinfo">معلومات العضو</SelectItem>
            <SelectItem value="member_join">انضمام عضو</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Realtime indicator */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className="h-2 w-2 rounded-full bg-success pulse-dot" />
        التحديث مباشر — يتم تحديث السجلات تلقائياً
      </div>

      {loading ? (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4"><div className="h-16 rounded bg-muted" /></CardContent>
            </Card>
          ))}
        </div>
      ) : logs.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center text-muted-foreground">
            <ScrollText className="h-12 w-12 mx-auto mb-3 opacity-50" />
            لا توجد سجلات
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {logs.map((log) => {
            const Icon = actionIcons[log.action] || Terminal;
            const colorClass = actionColors[log.action] || 'bg-muted text-muted-foreground';
            return (
              <Card key={log.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${colorClass}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="font-mono text-xs">{log.action}</Badge>
                        <span className="text-sm font-medium">{log.username || 'النظام'}</span>
                        {log.target_username && (
                          <>
                            <span className="text-xs text-muted-foreground">←</span>
                            <span className="text-sm text-muted-foreground">{log.target_username}</span>
                          </>
                        )}
                      </div>
                      {log.reason && (
                        <p className="text-sm text-muted-foreground mt-1">السبب: {log.reason}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(log.created_at).toLocaleString('ar-EG', {
                          dateStyle: 'medium',
                          timeStyle: 'short',
                        })}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>
            السابق
          </Button>
          <span className="text-sm text-muted-foreground">
            صفحة {page} من {totalPages}
          </span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
            التالي
          </Button>
        </div>
      )}
    </div>
  );
}

'use client';

import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Search, Users, ShieldBan, VolumeX, Crown, Check, X, UserCog } from 'lucide-react';
import type { Member, Server } from '@/lib/types';

interface MembersResponse {
  data: Member[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export default function MembersPage() {
  const { toast } = useToast();
  const [members, setMembers] = useState<Member[]>([]);
  const [servers, setServers] = useState<Server[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [serverFilter, setServerFilter] = useState<string>('all');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  const fetchMembers = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (serverFilter !== 'all') params.set('server_id', serverFilter);
    params.set('page', String(page));
    params.set('pageSize', '12');

    fetch(`/api/members?${params}`)
      .then((r) => r.json())
      .then((data: MembersResponse) => {
        setMembers(data.data || []);
        setTotalPages(data.totalPages || 1);
        setTotal(data.total || 0);
        setLoading(false);
      });
  }, [search, serverFilter, page]);

  useEffect(() => {
    fetch('/api/servers').then((r) => r.json()).then((data) => setServers(data || []));
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchMembers();
    }, 300);
    return () => clearTimeout(timer);
  }, [search, serverFilter]);

  useEffect(() => {
    fetchMembers();
  }, [page]);

  const executeCommand = async (command: string, member: Member) => {
    setActionLoading(true);
    try {
      const res = await fetch('/api/bot/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command,
          server_id: member.server_id,
          target_id: member.user_id,
        }),
      });
      if (res.ok) {
        toast({ title: 'تم التنفيذ', description: `تم تنفيذ الأمر: ${command}` });
        fetchMembers();
        setSelectedMember(null);
      } else {
        toast({ title: 'خطأ', description: 'فشل في تنفيذ الأمر', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'خطأ', description: 'حدث خطأ غير متوقع', variant: 'destructive' });
    }
    setActionLoading(false);
  };

  const serverName = (id: string) => servers.find((s) => s.server_id === id)?.name || id;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">الأعضاء</h1>
        <p className="text-muted-foreground mt-1">إدارة أعضاء السيرفرات ({total} عضو)</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث عن عضو..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10"
          />
        </div>
        <Select value={serverFilter} onValueChange={setServerFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="كل السيرفرات" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل السيرفرات</SelectItem>
            {servers.map((s) => (
              <SelectItem key={s.server_id} value={s.server_id}>{s.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Members grid */}
      {loading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4"><div className="h-16 rounded bg-muted" /></CardContent>
            </Card>
          ))}
        </div>
      ) : members.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
            لا يوجد أعضاء مطابقون
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {members.map((member) => (
            <Card
              key={member.id}
              className="hover:shadow-lg transition-all cursor-pointer hover:border-primary/30"
              onClick={() => setSelectedMember(member)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={member.avatar_url || undefined} />
                    <AvatarFallback className="bg-primary/10 text-primary text-sm">
                      {member.username.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium truncate">{member.nickname || member.username}</p>
                      {member.is_muted && <VolumeX className="h-3.5 w-3.5 text-warning shrink-0" />}
                      {member.is_banned && <ShieldBan className="h-3.5 w-3.5 text-destructive shrink-0" />}
                    </div>
                    <p className="text-xs text-muted-foreground truncate">{serverName(member.server_id)}</p>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {member.roles.slice(0, 2).map((role) => (
                        <Badge key={role} variant="outline" className="text-xs py-0">
                          {role}
                        </Badge>
                      ))}
                      {member.roles.length > 2 && (
                        <Badge variant="outline" className="text-xs py-0">
                          +{member.roles.length - 2}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>
            السابق
          </Button>
          <span className="text-sm text-muted-foreground">
            صفحة {page} من {totalPages}
          </span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
            التالي
          </Button>
        </div>
      )}

      {/* Member details dialog */}
      <Dialog open={!!selectedMember} onOpenChange={(open) => !open && setSelectedMember(null)}>
        <DialogContent className="max-w-md">
          {selectedMember && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={selectedMember.avatar_url || undefined} />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {selectedMember.username.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p>{selectedMember.nickname || selectedMember.username}</p>
                    <p className="text-sm text-muted-foreground font-normal">
                      {selectedMember.username}#{selectedMember.discriminator}
                    </p>
                  </div>
                </DialogTitle>
                <DialogDescription>
                  تفاصيل العضو وإجراءات الإدارة
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="rounded-lg border p-3">
                    <p className="text-xs text-muted-foreground">السيرفر</p>
                    <p className="font-medium truncate">{serverName(selectedMember.server_id)}</p>
                  </div>
                  <div className="rounded-lg border p-3">
                    <p className="text-xs text-muted-foreground">انضم في</p>
                    <p className="font-medium">
                      {selectedMember.joined_at
                        ? new Date(selectedMember.joined_at).toLocaleDateString('ar-EG')
                        : 'غير معروف'}
                    </p>
                  </div>
                  <div className="rounded-lg border p-3">
                    <p className="text-xs text-muted-foreground">معرف المستخدم</p>
                    <p className="font-mono text-xs">{selectedMember.user_id}</p>
                  </div>
                  <div className="rounded-lg border p-3">
                    <p className="text-xs text-muted-foreground">الحالة</p>
                    <div className="flex gap-1.5">
                      {selectedMember.is_banned && <Badge variant="destructive" className="text-xs">مطرود</Badge>}
                      {selectedMember.is_muted && <Badge className="bg-warning text-warning-foreground text-xs">مكتوم</Badge>}
                      {!selectedMember.is_banned && !selectedMember.is_muted && (
                        <Badge variant="secondary" className="text-xs">نشط</Badge>
                      )}
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border p-3">
                  <p className="text-xs text-muted-foreground mb-2">الأدوار ({selectedMember.roles.length})</p>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedMember.roles.map((role) => (
                      <Badge key={role} variant="outline" className="text-xs gap-1">
                        <Crown className="h-3 w-3" />
                        {role}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  {!selectedMember.is_muted ? (
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={actionLoading}
                      onClick={() => executeCommand('mute', selectedMember)}
                      className="gap-2"
                    >
                      <VolumeX className="h-4 w-4" /> كتم
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={actionLoading}
                      onClick={() => executeCommand('unmute', selectedMember)}
                      className="gap-2"
                    >
                      <Check className="h-4 w-4" /> إلغاء الكتم
                    </Button>
                  )}
                  {!selectedMember.is_banned ? (
                    <Button
                      variant="destructive"
                      size="sm"
                      disabled={actionLoading}
                      onClick={() => executeCommand('ban', selectedMember)}
                      className="gap-2"
                    >
                      <ShieldBan className="h-4 w-4" /> طرد
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={actionLoading}
                      onClick={() => executeCommand('unban', selectedMember)}
                      className="gap-2"
                    >
                      <Check className="h-4 w-4" /> إلغاء الطرد
                    </Button>
                  )}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

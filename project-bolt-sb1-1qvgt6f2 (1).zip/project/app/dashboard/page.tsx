'use client';

import { useEffect, useState } from 'react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Server, Users, Terminal, Activity, ShieldX, VolumeX, Bot, Zap } from 'lucide-react';
import type { Stats } from '@/lib/types';

const PIE_COLORS = ['hsl(235 86% 65%)', 'hsl(142 71% 45%)', 'hsl(38 92% 50%)', 'hsl(0 84% 60%)', 'hsl(199 89% 48%)'];

export default function DashboardHome() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/stats')
      .then((r) => r.json())
      .then((data) => {
        setStats(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-24 rounded bg-muted" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!stats) {
    return <div className="text-center text-muted-foreground">لا توجد بيانات</div>;
  }

  const statCards = [
    { label: 'السيرفرات', value: stats.totalServers, icon: Server, color: 'text-primary', bg: 'bg-primary/10' },
    { label: 'الأعضاء', value: stats.totalMembers, icon: Users, color: 'text-info', bg: 'bg-info/10' },
    { label: 'الأوامر المنفذة', value: stats.totalCommands, icon: Terminal, color: 'text-success', bg: 'bg-success/10' },
    { label: 'حالة البوت', value: stats.botStatus === 'online' ? 'متصل' : 'غير متصل', icon: Bot, color: 'text-success', bg: 'bg-success/10' },
    { label: 'الأعضاء المطرودون', value: stats.bannedMembers, icon: ShieldX, color: 'text-destructive', bg: 'bg-destructive/10' },
    { label: 'الأعضاء المكتومون', value: stats.mutedMembers, icon: VolumeX, color: 'text-warning', bg: 'bg-warning/10' },
    { label: 'السيرفرات النشطة', value: stats.activeServers, icon: Activity, color: 'text-primary', bg: 'bg-primary/10' },
    { label: 'معدل الأوامر', value: `${(stats.totalCommands / 7).toFixed(1)}/يوم`, icon: Zap, color: 'text-warning', bg: 'bg-warning/10' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">لوحة التحكم</h1>
        <p className="text-muted-foreground mt-1">نظرة عامة على إحصائيات البوت</p>
      </div>

      {/* Stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <Card key={i} className="card-glow hover:shadow-lg transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{card.label}</p>
                    <p className="text-2xl font-bold mt-1">{card.value}</p>
                  </div>
                  <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${card.bg}`}>
                    <Icon className={`h-6 w-6 ${card.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>الأوامر خلال الأسبوع</CardTitle>
            <CardDescription>عدد الأوامر المنفذة في آخر 7 أيام</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={stats.commandsByDay}>
                <defs>
                  <linearGradient id="colorCommands" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(235 86% 65%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(235 86% 65%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} reversed />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} orientation="right" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="count"
                  stroke="hsl(235 86% 65%)"
                  strokeWidth={2}
                  fill="url(#colorCommands)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>توزيع الأوامر حسب النوع</CardTitle>
            <CardDescription>أنواع الأوامر الأكثر استخداماً</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={stats.commandsByType}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={3}
                  dataKey="count"
                  nameKey="action"
                >
                  {stats.commandsByType.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-3 justify-center mt-2">
              {stats.commandsByType.slice(0, 5).map((item, i) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <span
                    className="h-3 w-3 rounded-full"
                    style={{ backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }}
                  />
                  <span className="text-muted-foreground">{item.action}</span>
                  <span className="font-medium">{item.count}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>الأعضاء حسب السيرفر</CardTitle>
            <CardDescription>توزيع الأعضاء على السيرفرات</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={stats.membersByServer}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} reversed />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} orientation="right" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="count" fill="hsl(235 86% 65%)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

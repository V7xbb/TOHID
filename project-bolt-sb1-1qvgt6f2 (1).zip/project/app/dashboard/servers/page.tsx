'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Server as ServerIcon, Users, Shield, Hash, Crown } from 'lucide-react';
import type { Server } from '@/lib/types';

export default function ServersPage() {
  const [servers, setServers] = useState<Server[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Server | null>(null);

  useEffect(() => {
    fetch('/api/servers')
      .then((r) => r.json())
      .then((data) => {
        setServers(data || []);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6"><div className="h-40 rounded bg-muted" /></CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">السيرفرات</h1>
        <p className="text-muted-foreground mt-1">السيرفرات التي يتواجد فيها البوت ({servers.length})</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {servers.map((server) => (
          <Card
            key={server.id}
            className="cursor-pointer hover:shadow-lg transition-all hover:border-primary/30"
            onClick={() => setSelected(server)}
          >
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <Avatar className="h-12 w-12 rounded-xl">
                  <AvatarImage src={server.icon_url || undefined} />
                  <AvatarFallback className="rounded-xl bg-primary/10">
                    <ServerIcon className="h-6 w-6 text-primary" />
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold truncate">{server.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {server.server_id}
                  </p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    <Badge variant="secondary" className="gap-1">
                      <Users className="h-3 w-3" />
                      {server.member_count}
                    </Badge>
                    <Badge variant="secondary" className="gap-1">
                      <Shield className="h-3 w-3" />
                      {server.role_count}
                    </Badge>
                    <Badge variant="secondary" className="gap-1">
                      <Hash className="h-3 w-3" />
                      {server.channel_count}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {selected && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
          onClick={() => setSelected(null)}
        >
          <Card className="w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
            <CardHeader>
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16 rounded-2xl">
                  <AvatarImage src={selected.icon_url || undefined} />
                  <AvatarFallback className="rounded-2xl bg-primary/10">
                    <ServerIcon className="h-8 w-8 text-primary" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-xl">{selected.name}</CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">{selected.server_id}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-xl border p-4 text-center">
                  <Users className="h-6 w-6 mx-auto text-info mb-2" />
                  <p className="text-2xl font-bold">{selected.member_count}</p>
                  <p className="text-xs text-muted-foreground">الأعضاء</p>
                </div>
                <div className="rounded-xl border p-4 text-center">
                  <Shield className="h-6 w-6 mx-auto text-success mb-2" />
                  <p className="text-2xl font-bold">{selected.role_count}</p>
                  <p className="text-xs text-muted-foreground">الأدوار</p>
                </div>
                <div className="rounded-xl border p-4 text-center">
                  <Hash className="h-6 w-6 mx-auto text-warning mb-2" />
                  <p className="text-2xl font-bold">{selected.channel_count}</p>
                  <p className="text-xs text-muted-foreground">القنوات</p>
                </div>
              </div>
              <div className="rounded-xl border p-4 space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Crown className="h-4 w-4 text-warning" />
                  <span className="text-muted-foreground">المالك:</span>
                  <span className="font-mono">{selected.owner_id}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">تاريخ الإنشاء:</span>
                  <span>{new Date(selected.created_at).toLocaleDateString('ar-EG')}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">آخر تحديث:</span>
                  <span>{new Date(selected.updated_at).toLocaleDateString('ar-EG')}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

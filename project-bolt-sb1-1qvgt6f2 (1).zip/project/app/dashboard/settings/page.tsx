'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Save, Bell, ScrollText, Shield, Bot, MessageSquare } from 'lucide-react';
import type { Server, BotSettings } from '@/lib/types';

export default function SettingsPage() {
  const { toast } = useToast();
  const [servers, setServers] = useState<Server[]>([]);
  const [settings, setSettings] = useState<BotSettings[]>([]);
  const [selectedServer, setSelectedServer] = useState<string>('');
  const [current, setCurrent] = useState<BotSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    Promise.all([
      fetch('/api/servers').then((r) => r.json()),
      fetch('/api/settings').then((r) => r.json()),
    ]).then(([serversData, settingsData]) => {
      setServers(serversData || []);
      setSettings(settingsData || []);
      if (serversData?.length > 0) {
        setSelectedServer(serversData[0].server_id);
      }
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    if (selectedServer) {
      const s = settings.find((s) => s.server_id === selectedServer);
      if (s) {
        setCurrent(s);
      } else {
        setCurrent({
          id: '',
          server_id: selectedServer,
          prefix: '!',
          welcome_enabled: true,
          welcome_channel_id: '',
          welcome_message: 'مرحباً {user} في {server}!',
          logs_enabled: true,
          logs_channel_id: '',
          security_enabled: true,
          auto_mod_enabled: false,
          updated_at: '',
        });
      }
    }
  }, [selectedServer, settings]);

  const handleSave = async () => {
    if (!current) return;
    setSaving(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(current),
      });
      if (res.ok) {
        toast({ title: 'تم الحفظ', description: 'تم تحديث إعدادات السيرفر بنجاح' });
        const updated = await fetch('/api/settings').then((r) => r.json());
        setSettings(updated || []);
      } else {
        toast({ title: 'خطأ', description: 'فشل في حفظ الإعدادات', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'خطأ', description: 'حدث خطأ غير متوقع', variant: 'destructive' });
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-32 rounded bg-muted" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold">الإعدادات</h1>
        <p className="text-muted-foreground">إدارة إعدادات البوت لكل سيرفر</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>اختر السيرفر</CardTitle>
          <CardDescription>اختر السيرفر الذي تريد تعديل إعداداته</CardDescription>
        </CardHeader>
        <CardContent>
          <Select value={selectedServer} onValueChange={setSelectedServer}>
            <SelectTrigger className="w-full md:w-80">
              <SelectValue placeholder="اختر سيرفر" />
            </SelectTrigger>
            <SelectContent>
              {servers.map((s) => (
                <SelectItem key={s.server_id} value={s.server_id}>
                  {s.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {current && (
        <div className="grid gap-4 md:grid-cols-2">
          {/* Commands */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <Bot className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle>إعدادات الأوامر</CardTitle>
                  <CardDescription>بادئة الأوامر</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="prefix">بادئة الأوامر</Label>
                <Input
                  id="prefix"
                  value={current.prefix}
                  onChange={(e) => setCurrent({ ...current, prefix: e.target.value })}
                  maxLength={3}
                  className="w-24 text-center text-lg font-bold"
                />
                <p className="text-xs text-muted-foreground">الرمز الذي يسبق الأوامر (مثل: !)</p>
              </div>
            </CardContent>
          </Card>

          {/* Welcome */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-success/10">
                    <MessageSquare className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <CardTitle>نظام الترحيب</CardTitle>
                    <CardDescription>ترحيب بالأعضاء الجدد</CardDescription>
                  </div>
                </div>
                <Switch
                  checked={current.welcome_enabled}
                  onCheckedChange={(v) => setCurrent({ ...current, welcome_enabled: v })}
                />
              </div>
            </CardHeader>
            <CardContent className={`space-y-4 ${!current.welcome_enabled ? 'opacity-50 pointer-events-none' : ''}`}>
              <div className="space-y-2">
                <Label htmlFor="welcome_channel">معرف قناة الترحيب</Label>
                <Input
                  id="welcome_channel"
                  value={current.welcome_channel_id || ''}
                  onChange={(e) => setCurrent({ ...current, welcome_channel_id: e.target.value })}
                  placeholder="123456789012345678"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="welcome_message">رسالة الترحيب</Label>
                <Textarea
                  id="welcome_message"
                  value={current.welcome_message}
                  onChange={(e) => setCurrent({ ...current, welcome_message: e.target.value })}
                  rows={3}
                  placeholder="مرحباً {user} في {server}!"
                />
                <p className="text-xs text-muted-foreground">استخدم {'{user}'} و{'{server}'} كمتغيرات</p>
              </div>
            </CardContent>
          </Card>

          {/* Logs */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-info/10">
                    <ScrollText className="h-5 w-5 text-info" />
                  </div>
                  <div>
                    <CardTitle>نظام السجلات</CardTitle>
                    <CardDescription>تسجيل الأوامر والأحداث</CardDescription>
                  </div>
                </div>
                <Switch
                  checked={current.logs_enabled}
                  onCheckedChange={(v) => setCurrent({ ...current, logs_enabled: v })}
                />
              </div>
            </CardHeader>
            <CardContent className={`space-y-4 ${!current.logs_enabled ? 'opacity-50 pointer-events-none' : ''}`}>
              <div className="space-y-2">
                <Label htmlFor="logs_channel">معرف قناة السجلات</Label>
                <Input
                  id="logs_channel"
                  value={current.logs_channel_id || ''}
                  onChange={(e) => setCurrent({ ...current, logs_channel_id: e.target.value })}
                  placeholder="123456789012345678"
                />
              </div>
            </CardContent>
          </Card>

          {/* Security */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-destructive/10">
                  <Shield className="h-5 w-5 text-destructive" />
                </div>
                <div>
                  <CardTitle>الأمان والحماية</CardTitle>
                  <CardDescription>إعدادات الحماية</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div>
                  <Label className="cursor-pointer">تفعيل الحماية</Label>
                  <p className="text-xs text-muted-foreground mt-1">حماية السيرفر من الهجمات</p>
                </div>
                <Switch
                  checked={current.security_enabled}
                  onCheckedChange={(v) => setCurrent({ ...current, security_enabled: v })}
                />
              </div>
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div>
                  <Label className="cursor-pointer">الإشراف التلقائي</Label>
                  <p className="text-xs text-muted-foreground mt-1">فلترة الرسائل تلقائياً</p>
                </div>
                <Switch
                  checked={current.auto_mod_enabled}
                  onCheckedChange={(v) => setCurrent({ ...current, auto_mod_enabled: v })}
                />
              </div>
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div>
                  <Label className="cursor-pointer">إشعارات الأمان</Label>
                  <p className="text-xs text-muted-foreground mt-1">تنبيه عند محاولة اختراق</p>
                </div>
                <Switch
                  checked={current.security_enabled}
                  onCheckedChange={(v) => setCurrent({ ...current, security_enabled: v })}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving} size="lg" className="min-w-32">
          <Save className="ml-2 h-4 w-4" />
          {saving ? 'جاري الحفظ...' : 'حفظ التغييرات'}
        </Button>
      </div>
    </div>
  );
}

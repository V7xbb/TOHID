import { Client, GatewayIntentBits, Partials, Events } from 'discord.js';
import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: false },
});

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.GuildMember, Partials.User],
});

async function logCommand(serverId, userId, username, action, targetId, targetUsername, reason, details) {
  try {
    await supabase.from('logs').insert({
      server_id: serverId,
      user_id: userId,
      username,
      action,
      target_id: targetId || null,
      target_username: targetUsername || null,
      reason: reason || null,
      details: details || {},
    });
  } catch (err) {
    console.error('Failed to log command:', err.message);
  }
}

async function getSettings(serverId) {
  const { data } = await supabase
    .from('settings')
    .select('*')
    .eq('server_id', serverId)
    .maybeSingle();
  return data;
}

client.once(Events.ClientReady, (c) => {
  console.log(`✅ Bot logged in as ${c.user.tag}`);
  console.log(`🌐 Connected to ${c.guilds.cache.size} servers`);

  c.guilds.cache.forEach(async (guild) => {
    try {
      await supabase.from('servers').upsert({
        server_id: guild.id,
        name: guild.name,
        icon_url: guild.iconURL(),
        owner_id: guild.ownerId,
        member_count: guild.memberCount,
        role_count: guild.roles.cache.size,
        channel_count: guild.channels.cache.size,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'server_id' });
    } catch (err) {
      console.error(`Failed to sync server ${guild.id}:`, err.message);
    }
  });
});

client.on(Events.GuildMemberAdd, async (member) => {
  try {
    const settings = await getSettings(member.guild.id);

    if (!settings?.welcome_enabled) return;

    const channel = settings.welcome_channel_id
      ? member.guild.channels.cache.get(settings.welcome_channel_id)
      : member.guild.systemChannel;

    if (channel && channel.isTextBased()) {
      const message = (settings.welcome_message || 'مرحباً {user} في {server}!')
        .replace('{user}', `<@${member.id}>`)
        .replace('{server}', member.guild.name);
      await channel.send(message);
    }

    await supabase.from('members').upsert({
      server_id: member.guild.id,
      user_id: member.id,
      username: member.user.username,
      discriminator: member.user.discriminator || '0',
      avatar_url: member.user.displayAvatarURL(),
      nickname: member.nickname,
      joined_at: member.joinedAt?.toISOString(),
      roles: member.roles.cache.map((r) => r.id),
    }, { onConflict: 'server_id,user_id' });

    await logCommand(member.guild.id, null, 'System', 'member_join', member.id, member.user.username, null, { guild: member.guild.name });
  } catch (err) {
    console.error('Welcome event error:', err.message);
  }
});

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot || !message.guild) return;

  const settings = await getSettings(message.guild.id);
  const prefix = settings?.prefix || '!';

  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/\s+/);
  const command = args.shift()?.toLowerCase();

  switch (command) {
    case 'ping': {
      const latency = client.ws.ping;
      await message.reply(`🏓 Pong! latency: ${latency}ms`);
      await logCommand(message.guild.id, message.author.id, message.author.username, 'ping', null, null, null, { latency: `${latency}ms` });
      break;
    }

    case 'echo': {
      const text = args.join(' ');
      if (!text) return message.reply('استخدام: `echo <رسالة>`');
      await message.channel.send(text);
      await logCommand(message.guild.id, message.author.id, message.author.username, 'echo', null, null, text, {});
      break;
    }

    case 'say': {
      const text = args.join(' ');
      if (!text) return message.reply('استخدام: `say <رسالة>`');
      await message.channel.send(text);
      await message.delete().catch(() => {});
      await logCommand(message.guild.id, message.author.id, message.author.username, 'say', null, null, text, { channel: message.channel.name });
      break;
    }

    case 'kick': {
      if (!message.member.permissions.has('KickMembers')) return message.reply('❌ ليس لديك صلاحية لطرد الأعضاء');
      const target = message.mentions.members.first();
      if (!target) return message.reply('استخدام: `kick @user [سبب]`');
      const reason = args.slice(1).join(' ') || 'بدون سبب';
      try {
        await target.kick(reason);
        await message.reply(`✅ تم طرد ${target.user.tag} — السبب: ${reason}`);
        await logCommand(message.guild.id, message.author.id, message.author.username, 'kick', target.id, target.user.tag, reason, {});
      } catch (err) {
        await message.reply(`❌ فشل الطرد: ${err.message}`);
      }
      break;
    }

    case 'ban': {
      if (!message.member.permissions.has('BanMembers')) return message.reply('❌ ليس لديك صلاحية لحظر الأعضاء');
      const target = message.mentions.members.first();
      if (!target) return message.reply('استخدام: `ban @user [سبب]`');
      const reason = args.slice(1).join(' ') || 'بدون سبب';
      try {
        await target.ban({ reason });
        await message.reply(`✅ تم حظر ${target.user.tag} — السبب: ${reason}`);
        await logCommand(message.guild.id, message.author.id, message.author.username, 'ban', target.id, target.user.tag, reason, { duration: 'permanent' });
      } catch (err) {
        await message.reply(`❌ فشل الحظر: ${err.message}`);
      }
      break;
    }

    case 'clear': {
      if (!message.member.permissions.has('ManageMessages')) return message.reply('❌ ليس لديك صلاحية لإدارة الرسائل');
      const count = parseInt(args[0]) || 10;
      if (count < 1 || count > 100) return message.reply('العدد يجب أن يكون بين 1 و 100');
      try {
        await message.channel.bulkDelete(count, true);
        await message.channel.send(`🧹 تم مسح ${count} رسالة`).then((m) => setTimeout(() => m.delete(), 3000));
        await logCommand(message.guild.id, message.author.id, message.author.username, 'clear', null, null, `مسح ${count} رسالة`, { count });
      } catch (err) {
        await message.reply(`❌ فشل المسح: ${err.message}`);
      }
      break;
    }

    case 'serverinfo': {
      const g = message.guild;
      const embed = {
        color: 0x5865f2,
        title: g.name,
        thumbnail: { url: g.iconURL() || '' },
        fields: [
          { name: '🆔 ID', value: g.id, inline: true },
          { name: '👥 الأعضاء', value: String(g.memberCount), inline: true },
          { name: '🎭 الأدوار', value: String(g.roles.cache.size), inline: true },
          { name: '📺 القنوات', value: String(g.channels.cache.size), inline: true },
          { name: '📅 تاريخ الإنشاء', value: g.createdAt.toDateString(), inline: true },
          { name: '👑 المالك', value: `<@${g.ownerId}>`, inline: true },
        ],
        footer: { text: 'Discord Bot Dashboard' },
      };
      await message.reply({ embeds: [embed] });
      await logCommand(message.guild.id, message.author.id, message.author.username, 'serverinfo', null, null, null, {});
      break;
    }

    case 'userinfo': {
      const target = message.mentions.members.first() || message.member;
      const embed = {
        color: 0x5865f2,
        title: target.user.tag,
        thumbnail: { url: target.user.displayAvatarURL() },
        fields: [
          { name: '🆔 ID', value: target.id, inline: true },
          { name: '📅 انضم للسيرفر', value: target.joinedAt?.toDateString() || 'غير معروف', inline: true },
          { name: '📅 إنشاء الحساب', value: target.user.createdAt.toDateString(), inline: true },
          { name: '🎭 الأدوار', value: target.roles.cache.map((r) => r.name).join(', ') || 'لا يوجد', inline: false },
        ],
        footer: { text: 'Discord Bot Dashboard' },
      };
      await message.reply({ embeds: [embed] });
      await logCommand(message.guild.id, message.author.id, message.author.username, 'userinfo', target.id, target.user.tag, null, {});
      break;
    }

    case 'help': {
      const embed = {
        color: 0x5865f2,
        title: '📜 أوامر البوت',
        description: [
          `**${prefix}ping** — فحص استجابة البوت`,
          `**${prefix}echo <رسالة>** — تكرار رسالة`,
          `**${prefix}say <رسالة>** — إرسال رسالة كالبوت`,
          `**${prefix}kick @user [سبب]** — طرد عضو`,
          `**${prefix}ban @user [سبب]** — حظر عضو`,
          `**${prefix}clear <عدد>** — مسح رسائل`,
          `**${prefix}serverinfo** — معلومات السيرفر`,
          `**${prefix}userinfo @user** — معلومات عضو`,
          `**${prefix}help** — عرض هذه القائمة`,
        ].join('\n'),
      };
      await message.reply({ embeds: [embed] });
      break;
    }
  }
});

client.login(process.env.BOT_TOKEN);

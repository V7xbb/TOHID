export interface BotAdmin {
  discord_user_id: string;
  username: string;
  avatar_url: string | null;
  role: 'admin' | 'moderator';
  created_at: string;
}

export interface Server {
  id: string;
  server_id: string;
  name: string;
  icon_url: string | null;
  owner_id: string | null;
  member_count: number;
  role_count: number;
  channel_count: number;
  created_at: string;
  updated_at: string;
}

export interface Member {
  id: string;
  server_id: string;
  user_id: string;
  username: string;
  discriminator: string;
  avatar_url: string | null;
  nickname: string | null;
  joined_at: string | null;
  roles: string[];
  is_muted: boolean;
  is_banned: boolean;
  created_at: string;
}

export interface BotSettings {
  id: string;
  server_id: string;
  prefix: string;
  welcome_enabled: boolean;
  welcome_channel_id: string | null;
  welcome_message: string;
  logs_enabled: boolean;
  logs_channel_id: string | null;
  security_enabled: boolean;
  auto_mod_enabled: boolean;
  updated_at: string;
}

export interface BotLog {
  id: string;
  server_id: string | null;
  user_id: string | null;
  username: string | null;
  action: string;
  target_id: string | null;
  target_username: string | null;
  reason: string | null;
  details: Record<string, unknown> | null;
  created_at: string;
}

export interface Stats {
  totalServers: number;
  totalMembers: number;
  totalCommands: number;
  botStatus: 'online' | 'offline';
  activeServers: number;
  bannedMembers: number;
  mutedMembers: number;
  commandsByDay: { date: string; count: number }[];
  commandsByType: { action: string; count: number }[];
  membersByServer: { name: string; count: number }[];
}

/*
# Discord Bot Management — Database Schema

Creates the core tables for a Discord bot management dashboard:
- `bot_admins`: Discord users authorized to use the dashboard (admin list).
- `servers`: Discord servers the bot is in.
- `members`: Members across servers.
- `settings`: Per-server bot settings (prefix, feature toggles).
- `logs`: Audit log of bot commands and events.

All tables use RLS. An `is_admin()` SECURITY DEFINER function checks membership
in bot_admins so policies stay declarative.
*/

-- ─── bot_admins (must exist before is_admin function) ───
CREATE TABLE IF NOT EXISTS public.bot_admins (
  discord_user_id text PRIMARY KEY,
  username text NOT NULL,
  avatar_url text,
  role text NOT NULL DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ─── Helper function: is the current authenticated user a bot admin? ───
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.bot_admins
    WHERE discord_user_id = (auth.jwt() ->> 'provider_id')
       OR discord_user_id = (auth.jwt() ->> 'sub')
  );
$$;

-- ─── servers ───
CREATE TABLE IF NOT EXISTS public.servers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id text UNIQUE NOT NULL,
  name text NOT NULL,
  icon_url text,
  owner_id text,
  member_count integer NOT NULL DEFAULT 0,
  role_count integer NOT NULL DEFAULT 0,
  channel_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ─── members ───
CREATE TABLE IF NOT EXISTS public.members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id text NOT NULL,
  user_id text NOT NULL,
  username text NOT NULL,
  discriminator text DEFAULT '0',
  avatar_url text,
  nickname text,
  joined_at timestamptz,
  roles text[] NOT NULL DEFAULT '{}',
  is_muted boolean NOT NULL DEFAULT false,
  is_banned boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (server_id, user_id)
);

-- ─── settings ───
CREATE TABLE IF NOT EXISTS public.settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id text UNIQUE NOT NULL,
  prefix text NOT NULL DEFAULT '!',
  welcome_enabled boolean NOT NULL DEFAULT true,
  welcome_channel_id text,
  welcome_message text NOT NULL DEFAULT 'مرحباً {user} في {server}!',
  logs_enabled boolean NOT NULL DEFAULT true,
  logs_channel_id text,
  security_enabled boolean NOT NULL DEFAULT true,
  auto_mod_enabled boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ─── logs ───
CREATE TABLE IF NOT EXISTS public.logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id text,
  user_id text,
  username text,
  action text NOT NULL,
  target_id text,
  target_username text,
  reason text,
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ─── Enable RLS on all tables ───
ALTER TABLE public.bot_admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.servers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.logs ENABLE ROW LEVEL SECURITY;

-- ─── bot_admins policies ───
DROP POLICY IF EXISTS "admins_select" ON public.bot_admins;
CREATE POLICY "admins_select" ON public.bot_admins
  FOR SELECT TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "admins_insert" ON public.bot_admins;
CREATE POLICY "admins_insert" ON public.bot_admins
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admins_update" ON public.bot_admins;
CREATE POLICY "admins_update" ON public.bot_admins
  FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admins_delete" ON public.bot_admins;
CREATE POLICY "admins_delete" ON public.bot_admins
  FOR DELETE TO authenticated USING (public.is_admin());

-- ─── servers policies ───
DROP POLICY IF EXISTS "servers_select" ON public.servers;
CREATE POLICY "servers_select" ON public.servers
  FOR SELECT TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "servers_insert" ON public.servers;
CREATE POLICY "servers_insert" ON public.servers
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "servers_update" ON public.servers;
CREATE POLICY "servers_update" ON public.servers
  FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "servers_delete" ON public.servers;
CREATE POLICY "servers_delete" ON public.servers
  FOR DELETE TO authenticated USING (public.is_admin());

-- ─── members policies ───
DROP POLICY IF EXISTS "members_select" ON public.members;
CREATE POLICY "members_select" ON public.members
  FOR SELECT TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "members_insert" ON public.members;
CREATE POLICY "members_insert" ON public.members
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "members_update" ON public.members;
CREATE POLICY "members_update" ON public.members
  FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "members_delete" ON public.members;
CREATE POLICY "members_delete" ON public.members
  FOR DELETE TO authenticated USING (public.is_admin());

-- ─── settings policies ───
DROP POLICY IF EXISTS "settings_select" ON public.settings;
CREATE POLICY "settings_select" ON public.settings
  FOR SELECT TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "settings_insert" ON public.settings;
CREATE POLICY "settings_insert" ON public.settings
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "settings_update" ON public.settings;
CREATE POLICY "settings_update" ON public.settings
  FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "settings_delete" ON public.settings;
CREATE POLICY "settings_delete" ON public.settings
  FOR DELETE TO authenticated USING (public.is_admin());

-- ─── logs policies ───
DROP POLICY IF EXISTS "logs_select" ON public.logs;
CREATE POLICY "logs_select" ON public.logs
  FOR SELECT TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "logs_insert" ON public.logs;
CREATE POLICY "logs_insert" ON public.logs
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "logs_update" ON public.logs;
CREATE POLICY "logs_update" ON public.logs
  FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "logs_delete" ON public.logs;
CREATE POLICY "logs_delete" ON public.logs
  FOR DELETE TO authenticated USING (public.is_admin());

-- ─── Indexes ───
CREATE INDEX IF NOT EXISTS idx_members_server_id ON public.members (server_id);
CREATE INDEX IF NOT EXISTS idx_members_username ON public.members (username);
CREATE INDEX IF NOT EXISTS idx_logs_server_id ON public.logs (server_id);
CREATE INDEX IF NOT EXISTS idx_logs_created_at ON public.logs (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_logs_action ON public.logs (action);
CREATE INDEX IF NOT EXISTS idx_settings_server_id ON public.settings (server_id);

-- ─── Seed data ───
INSERT INTO public.bot_admins (discord_user_id, username, avatar_url, role)
VALUES ('1544878719418634320', 'Bot Owner', NULL, 'admin')
ON CONFLICT (discord_user_id) DO NOTHING;

INSERT INTO public.servers (server_id, name, icon_url, owner_id, member_count, role_count, channel_count)
VALUES
  ('876543210987654321', 'سيرفر المجتمع العربي', 'https://cdn.discordapp.com/embed/avatars/0.png', '1544878719418634320', 1250, 8, 24),
  ('987654321098765432', 'سيرفر الألعاب', 'https://cdn.discordapp.com/embed/avatars/1.png', '1544878719418634320', 856, 6, 18),
  ('765432109876543210', 'سيرفر البرمجة', 'https://cdn.discordapp.com/embed/avatars/2.png', '1544878719418634320', 432, 5, 12)
ON CONFLICT (server_id) DO NOTHING;

INSERT INTO public.settings (server_id, prefix, welcome_enabled, welcome_channel_id, welcome_message, logs_enabled, logs_channel_id, security_enabled, auto_mod_enabled)
VALUES
  ('876543210987654321', '!', true, '876543210987654330', 'مرحباً {user} في {server}! نورت السيرفر', true, '876543210987654331', true, true),
  ('987654321098765432', '?', true, '987654321098765440', 'أهلاً وسهلاً {user} في {server}', true, '987654321098765441', true, false),
  ('765432109876543210', '#', false, NULL, 'مرحباً {user}!', false, NULL, true, false)
ON CONFLICT (server_id) DO NOTHING;

INSERT INTO public.members (server_id, user_id, username, discriminator, avatar_url, nickname, joined_at, roles, is_muted, is_banned)
VALUES
  ('876543210987654321', '111111111111111111', 'أحمد', '0001', 'https://cdn.discordapp.com/embed/avatars/0.png', 'أحمد المطور', '2024-01-15T10:30:00Z', ARRAY['admin', 'member'], false, false),
  ('876543210987654321', '222222222222222222', 'محمد', '0002', 'https://cdn.discordapp.com/embed/avatars/1.png', NULL, '2024-02-20T14:00:00Z', ARRAY['member'], false, false),
  ('876543210987654321', '333333333333333333', 'سارة', '0003', 'https://cdn.discordapp.com/embed/avatars/2.png', 'سارة المصممة', '2024-03-10T09:15:00Z', ARRAY['moderator', 'member'], true, false),
  ('987654321098765432', '444444444444444444', 'علي', '0004', 'https://cdn.discordapp.com/embed/avatars/3.png', NULL, '2024-01-05T16:45:00Z', ARRAY['member'], false, false),
  ('987654321098765432', '555555555555555555', 'فاطمة', '0005', 'https://cdn.discordapp.com/embed/avatars/4.png', 'فاطمة القائدة', '2024-05-12T11:20:00Z', ARRAY['admin', 'member'], false, false),
  ('765432109876543210', '666666666666666666', 'خالد', '0006', 'https://cdn.discordapp.com/embed/avatars/5.png', NULL, '2024-02-28T08:00:00Z', ARRAY['member'], false, true),
  ('765432109876543210', '777777777777777777', 'نورة', '0007', 'https://cdn.discordapp.com/embed/avatars/0.png', NULL, '2024-05-01T13:30:00Z', ARRAY['moderator', 'member'], false, false)
ON CONFLICT (server_id, user_id) DO NOTHING;

INSERT INTO public.logs (server_id, user_id, username, action, target_id, target_username, reason, details, created_at)
VALUES
  ('876543210987654321', '1544878719418634320', 'Bot Owner', 'kick', '333333333333333333', 'سارة', 'انتهاك القوانين', '{"channel": "general"}'::jsonb, now() - interval '1 hour'),
  ('876543210987654321', '111111111111111111', 'أحمد', 'ban', '666666666666666666', 'خالد', 'سبام متكرر', '{"duration": "permanent"}'::jsonb, now() - interval '2 hours'),
  ('987654321098765432', '555555555555555555', 'فاطمة', 'clear', NULL, NULL, 'تنظيف القناة', '{"count": 50}'::jsonb, now() - interval '3 hours'),
  ('876543210987654321', '1544878719418634320', 'Bot Owner', 'ping', NULL, NULL, NULL, '{"latency": "42ms"}'::jsonb, now() - interval '5 hours'),
  ('765432109876543210', '777777777777777777', 'نورة', 'say', NULL, NULL, 'إعلان', '{"channel": "announcements"}'::jsonb, now() - interval '6 hours'),
  ('876543210987654321', NULL, 'System', 'member_join', '222222222222222222', 'محمد', NULL, '{}'::jsonb, now() - interval '8 hours'),
  ('987654321098765432', '444444444444444444', 'علي', 'mute', '333333333333333333', 'سارة', 'إزعاج الأعضاء', '{"duration": "1h"}'::jsonb, now() - interval '12 hours'),
  ('876543210987654321', '1544878719418634320', 'Bot Owner', 'serverinfo', NULL, NULL, NULL, '{}'::jsonb, now() - interval '1 day'),
  ('765432109876543210', '777777777777777777', 'نورة', 'userinfo', '666666666666666666', 'خالد', NULL, '{}'::jsonb, now() - interval '2 days'),
  ('987654321098765432', '555555555555555555', 'فاطمة', 'echo', NULL, NULL, 'رسالة تجريبية', '{}'::jsonb, now() - interval '3 days')
ON CONFLICT DO NOTHING;
